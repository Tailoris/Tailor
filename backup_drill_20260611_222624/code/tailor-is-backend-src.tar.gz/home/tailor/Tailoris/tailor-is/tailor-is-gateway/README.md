# Gateway 服务

Tailor IS API 网关微服务

## 功能概述

- 统一 API 入口，路由转发至后端微服务
- 全局鉴权过滤器 (AuthGlobalFilter) + SA-Token 集成
- 基于 Redis 的全局限流 (登录/注册/支付接口特殊限流)
- CORS 跨域配置管理
- Sentinel 流控熔断 + Prometheus 监控指标暴露

## 技术栈

- Spring Boot 3.x
- Spring Cloud Gateway (WebFlux)
- Spring Cloud Alibaba
- Nacos (服务注册/配置中心)
- Sentinel (限流熔断)
- SA-Token (鉴权)
- Redis (限流计数)

## 启动方式

```bash
# 设置环境变量
export NACOS_ADDR=localhost:8848
export REDIS_HOST=localhost
export REDIS_PORT=6379
export REDIS_PASSWORD=

# 启动服务
./mvnw spring-boot:run
```

## API 文档

网关本身不提供 Swagger 文档，各业务服务文档通过网关聚合访问。

## 配置

配置文件位于 `src/main/resources/application.yml`

### 关键配置项

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| server.port | 服务端口 | 8080 |
| spring.cloud.nacos.discovery.server-addr | Nacos地址 | ${NACOS_ADDR} |
| tailoris.gateway.ratelimit.default-permits-per-second | 全局限流 | 100 req/s |
| tailoris.gateway.ratelimit.login-permits-per-minute | 登录限流 | 10 req/min |

## 健康检查

```bash
curl http://localhost:8080/actuator/health
```

## 日志

日志配置由 `logback-spring.xml` 统一管理。

## 依赖关系

- 依赖服务: Nacos, Redis
- 被依赖: 所有前端/客户端请求入口
- 路由转发: 所有后端微服务
