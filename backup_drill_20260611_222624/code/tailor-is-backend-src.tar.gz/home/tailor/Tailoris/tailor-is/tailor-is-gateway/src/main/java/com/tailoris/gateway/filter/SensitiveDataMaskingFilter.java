package com.tailoris.gateway.filter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.http.server.reactive.ServerHttpResponseDecorator;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 敏感数据脱敏过滤器 - 阶段5 性能与安全加固
 *
 * <p>在网关层对请求/响应中的敏感数据进行脱敏：</p>
 * <ul>
 *   <li>身份证号 → 110101********1234</li>
 *   <li>手机号 → 138****5678</li>
 *   <li>银行卡号 → 6222 **** **** 1234</li>
 *   <li>邮箱 → a***@example.com</li>
 *   <li>密码字段 → 完全替换为 ******</li>
 *   <li>Token/JWT → 仅保留前4后4位</li>
 * </ul>
 *
 * @author Tailor IS Team
 * @since 1.2.0
 */
@Slf4j
@Component
public class SensitiveDataMaskingFilter implements GlobalFilter, Ordered {

    // 18 位身份证
    private static final Pattern ID_CARD = Pattern.compile("(\\d{4})\\d{10}(\\w{4})");
    // 11 位手机号
    private static final Pattern MOBILE = Pattern.compile("(?<!\\d)1[3-9]\\d{1}(\\d{4})\\d{4}(?!\\d)");
    // 银行卡号 (16-19 位)
    private static final Pattern BANK_CARD = Pattern.compile("(\\d{4})\\d{8,11}(\\d{4})");
    // 邮箱
    private static final Pattern EMAIL = Pattern.compile("([a-zA-Z0-9])[a-zA-Z0-9._%+-]*(@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,})");
    // 密码字段
    private static final Pattern PASSWORD = Pattern.compile(
            "(\"(?:password|pwd|passwd|secret)\"\\s*:\\s*\")([^\"]*)(\")",
            Pattern.CASE_INSENSITIVE);
    // Token / Bearer
    private static final Pattern TOKEN = Pattern.compile("(?i)(Bearer\\s+)([A-Za-z0-9._\\-]+)");

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        MediaType contentType = request.getHeaders().getContentType();
        // 仅对 JSON 请求和响应进行脱敏
        boolean isJson = contentType != null
                && contentType.toString().toLowerCase().contains("application/json");

        if (!isJson) {
            return chain.filter(exchange);
        }

        // 装饰 Response
        ServerHttpResponseDecorator decoratedResponse = new ServerHttpResponseDecorator(exchange.getResponse()) {
            @Override
            public Mono<Void> writeWith(org.reactivestreams.Publisher<? extends DataBuffer> body) {
                Flux<DataBuffer> flux = Flux.from(body);
                return super.writeWith(flux.buffer().map(dataBuffers -> {
                    DataBuffer joined = exchange.getResponse().bufferFactory().join(dataBuffers);
                    byte[] content = new byte[joined.readableByteCount()];
                    joined.read(content);
                    DataBufferUtils.release(joined);

                    String original = new String(content, StandardCharsets.UTF_8);
                    String masked = maskSensitiveData(original);
                    byte[] maskedBytes = masked.getBytes(StandardCharsets.UTF_8);

                    getHeaders().setContentLength(maskedBytes.length);
                    return exchange.getResponse().bufferFactory().wrap(maskedBytes);
                }));
            }
        };

        return chain.filter(exchange.mutate().response(decoratedResponse).build());
    }

    /** 对文本中的敏感数据进行脱敏 */
    public String maskSensitiveData(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        String result = input;
        // 身份证
        result = ID_CARD.matcher(result).replaceAll("$1**********$2");
        // 手机号 (需要特殊处理，避免破坏 JSON 中的数字)
        result = MOBILE.matcher(result).replaceAll(matchResult -> {
            String full = matchResult.group();
            return full.substring(0, 3) + "****" + full.substring(7);
        });
        // 银行卡
        result = BANK_CARD.matcher(result).replaceAll("$1********$2");
        // 邮箱
        result = EMAIL.matcher(result).replaceAll("$1***$2");
        // 密码
        result = PASSWORD.matcher(result).replaceAll("$1******$3");
        // Token
        result = TOKEN.matcher(result).replaceAll(matchResult -> {
            String full = matchResult.group();
            String token = matchResult.group(2);
            if (token.length() > 8) {
                return matchResult.group(1) + token.substring(0, 4) + "***" + token.substring(token.length() - 4);
            }
            return matchResult.group(1) + "***";
        });
        return result;
    }

    @Override
    public int getOrder() {
        return -5;  // 在 SecurityHeaders 之后
    }
}
