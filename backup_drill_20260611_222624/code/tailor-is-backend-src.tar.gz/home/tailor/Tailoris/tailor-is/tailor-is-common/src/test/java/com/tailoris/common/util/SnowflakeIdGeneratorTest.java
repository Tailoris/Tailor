package com.tailoris.common.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("SnowflakeIdGenerator 测试")
class SnowflakeIdGeneratorTest {

    @Nested
    @DisplayName("实例创建测试")
    class InstanceCreationTests {

        @Test
        @DisplayName("使用指定参数创建实例")
        void testCreateInstanceWithParameters() {
            SnowflakeIdGenerator generator = SnowflakeIdGenerator.getInstance(1, 1);
            assertNotNull(generator);
            assertEquals(1, generator.getWorkerId());
            assertEquals(1, generator.getDatacenterId());
        }

        @Test
        @DisplayName("获取单例实例")
        void testGetInstance() {
            SnowflakeIdGenerator instance1 = SnowflakeIdGenerator.getInstance();
            SnowflakeIdGenerator instance2 = SnowflakeIdGenerator.getInstance();
            assertSame(instance1, instance2);
        }

        @Test
        @DisplayName("workerId 超出范围抛出异常")
        void testInvalidWorkerId() {
            assertThrows(IllegalArgumentException.class, () -> SnowflakeIdGenerator.getInstance(32, 1));
        }

        @Test
        @DisplayName("datacenterId 超出范围抛出异常")
        void testInvalidDatacenterId() {
            assertThrows(IllegalArgumentException.class, () -> SnowflakeIdGenerator.getInstance(1, 32));
        }

        @Test
        @DisplayName("workerId 为负数抛出异常")
        void testNegativeWorkerId() {
            assertThrows(IllegalArgumentException.class, () -> SnowflakeIdGenerator.getInstance(-1, 1));
        }

        @Test
        @DisplayName("datacenterId 为负数抛出异常")
        void testNegativeDatacenterId() {
            assertThrows(IllegalArgumentException.class, () -> SnowflakeIdGenerator.getInstance(1, -1));
        }
    }

    @Nested
    @DisplayName("ID 生成测试")
    class IdGenerationTests {

        @Test
        @DisplayName("生成单个 ID")
        void testGenerateSingleId() {
            SnowflakeIdGenerator generator = SnowflakeIdGenerator.getInstance(1, 1);
            long id = generator.nextId();
            assertTrue(id > 0);
        }

        @Test
        @DisplayName("生成的 ID 是正数")
        void testGeneratedIdIsPositive() {
            SnowflakeIdGenerator generator = SnowflakeIdGenerator.getInstance(1, 1);
            for (int i = 0; i < 100; i++) {
                long id = generator.nextId();
                assertTrue(id > 0, "ID should be positive");
            }
        }

        @Test
        @DisplayName("生成的 ID 是唯一的")
        void testGeneratedIdsAreUnique() {
            SnowflakeIdGenerator generator = SnowflakeIdGenerator.getInstance(2, 2);
            Set<Long> ids = new HashSet<>();
            int count = 10000;
            for (int i = 0; i < count; i++) {
                ids.add(generator.nextId());
            }
            assertEquals(count, ids.size(), "All generated IDs should be unique");
        }

        @Test
        @DisplayName("生成的 ID 是递增的")
        void testGeneratedIdsAreIncrementing() {
            SnowflakeIdGenerator generator = SnowflakeIdGenerator.getInstance(3, 3);
            long previousId = generator.nextId();
            for (int i = 0; i < 100; i++) {
                long currentId = generator.nextId();
                assertTrue(currentId > previousId, "ID should be monotonically increasing");
                previousId = currentId;
            }
        }

        @Test
        @DisplayName("不同 workerId 生成的 ID 不同")
        void testDifferentWorkerIdsGenerateDifferentIds() {
            SnowflakeIdGenerator generator1 = SnowflakeIdGenerator.getInstance(1, 1);
            SnowflakeIdGenerator generator2 = SnowflakeIdGenerator.getInstance(2, 1);
            long id1 = generator1.nextId();
            long id2 = generator2.nextId();
            assertNotEquals(id1, id2);
        }

        @Test
        @DisplayName("不同 datacenterId 生成的 ID 不同")
        void testDifferentDatacenterIdsGenerateDifferentIds() {
            SnowflakeIdGenerator generator1 = SnowflakeIdGenerator.getInstance(1, 1);
            SnowflakeIdGenerator generator2 = SnowflakeIdGenerator.getInstance(1, 2);
            long id1 = generator1.nextId();
            long id2 = generator2.nextId();
            assertNotEquals(id1, id2);
        }

        @Test
        @DisplayName("生成的 ID 在合理范围内")
        void testGeneratedIdRange() {
            SnowflakeIdGenerator generator = SnowflakeIdGenerator.getInstance(1, 1);
            long id = generator.nextId();
            long maxSnowflakeId = Long.MAX_VALUE;
            assertTrue(id > 0 && id < maxSnowflakeId, "ID should be within reasonable range");
        }

        @Test
        @DisplayName("高并发下 ID 唯一性")
        void testUniquenessUnderConcurrency() throws InterruptedException {
            SnowflakeIdGenerator generator = SnowflakeIdGenerator.getInstance(5, 5);
            int threadCount = 10;
            int idsPerThread = 1000;
            Set<Long> ids = new HashSet<>();

            Thread[] threads = new Thread[threadCount];
            for (int t = 0; t < threadCount; t++) {
                threads[t] = new Thread(() -> {
                    for (int i = 0; i < idsPerThread; i++) {
                        synchronized (ids) {
                            ids.add(generator.nextId());
                        }
                    }
                });
            }

            for (Thread thread : threads) {
                thread.start();
            }

            for (Thread thread : threads) {
                thread.join();
            }

            assertEquals(threadCount * idsPerThread, ids.size(), "All IDs should be unique under concurrency");
        }
    }
}
