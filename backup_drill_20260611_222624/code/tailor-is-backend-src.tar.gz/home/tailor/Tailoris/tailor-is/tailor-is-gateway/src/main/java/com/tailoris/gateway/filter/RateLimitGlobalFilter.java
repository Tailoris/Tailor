package com.tailoris.gateway.filter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 网关层限流过滤器 - 阶段5 性能与安全加固
 *
 * <p>基于 Redis 的分布式限流：</p>
 * <ul>
 *   <li>默认按 IP 限流：100 req/s</li>
 *   <li>登录/注册接口严格限流：10 req/min</li>
 *   <li>支付等关键接口：10 req/s</li>
 *   <li>Redis 不可用时降级到本地限流</li>
 * </ul>
 *
 * @author Tailor IS Team
 * @since 1.2.0
 */
@Slf4j
@Component
public class RateLimitGlobalFilter implements GlobalFilter, Ordered {

    @Value("${tailoris.gateway.ratelimit.enabled:true}")
    private boolean enabled;

    @Value("${tailoris.gateway.ratelimit.default-permits-per-second:100}")
    private int defaultPermitsPerSecond;

    @Value("${tailoris.gateway.ratelimit.login-permits-per-minute:10}")
    private int loginPermitsPerMinute;

    private final StringRedisTemplate stringRedisTemplate;
    private final ObjectMapper objectMapper;
    private final AntPathMatcher pathMatcher = new AntPathMatcher();

    /** 本地降级限流计数 */
    private final java.util.concurrent.ConcurrentHashMap<String, AtomicLong> localCounters =
            new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.concurrent.ConcurrentHashMap<String, Long> localResetTimes =
            new java.util.concurrent.ConcurrentHashMap<>();

    public RateLimitGlobalFilter(StringRedisTemplate stringRedisTemplate, ObjectMapper objectMapper) {
        this.stringRedisTemplate = stringRedisTemplate;
        this.objectMapper = objectMapper;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        if (!enabled) {
            return chain.filter(exchange);
        }

        ServerHttpRequest request = exchange.getRequest();
        String path = request.getPath().toString();

        // 仅对 /api/** 限流
        if (!path.startsWith("/api/")) {
            return chain.filter(exchange);
        }

        // 计算限流参数
        RateLimitConfig config = resolveConfig(path);
        String clientIp = getClientIp(request);
        String key = "ratelimit:gw:" + config.name + ":" + clientIp;

        try {
            return doRedisLimit(key, config, exchange, chain);
        } catch (Exception e) {
            log.warn("Redis 限流异常，降级到本地: {}", e.getMessage());
            return doLocalLimit(key, config, exchange, chain);
        }
    }

    private RateLimitConfig resolveConfig(String path) {
        // 登录/注册：10 req/min
        if (pathMatcher.match("/api/auth/login", path) || pathMatcher.match("/api/auth/register", path)) {
            return new RateLimitConfig("login", loginPermitsPerMinute, 60L);
        }
        // 支付/账户：10 req/s
        if (pathMatcher.match("/api/payment/**", path) || pathMatcher.match("/api/account/**", path)) {
            return new RateLimitConfig("payment", 10, 1L);
        }
        // 默认：100 req/s
        return new RateLimitConfig("default", defaultPermitsPerSecond, 1L);
    }

    private Mono<Void> doRedisLimit(String key, RateLimitConfig config,
                                    ServerWebExchange exchange, GatewayFilterChain chain) {
        Long count = stringRedisTemplate.opsForValue().increment(key);
        if (count != null && count == 1L) {
            stringRedisTemplate.expire(key, config.windowSeconds, TimeUnit.SECONDS);
        }
        long current = count == null ? 0 : count;
        if (current > config.limit) {
            log.warn("触发限流 [{}]: key={}, count={}/{}", config.name, key, current, config.limit);
            ServerHttpResponse response = exchange.getResponse();
            response.getHeaders().add("X-RateLimit-Limit", String.valueOf(config.limit));
            response.getHeaders().add("X-RateLimit-Remaining", "0");
            response.getHeaders().add("Retry-After", String.valueOf(config.windowSeconds));
            return rateLimitResponse(response, config);
        }

        // 透传 RateLimit 头
        ServerHttpResponse response = exchange.getResponse();
        response.getHeaders().add("X-RateLimit-Limit", String.valueOf(config.limit));
        response.getHeaders().add("X-RateLimit-Remaining", String.valueOf(Math.max(0, config.limit - current)));
        return chain.filter(exchange);
    }

    private Mono<Void> doLocalLimit(String key, RateLimitConfig config,
                                    ServerWebExchange exchange, GatewayFilterChain chain) {
        long now = System.currentTimeMillis();
        Long resetTime = localResetTimes.get(key);
        if (resetTime == null || now > resetTime) {
            localCounters.computeIfAbsent(key, k -> new AtomicLong(0));
            localResetTimes.put(key, now + config.windowSeconds * 1000L);
        }
        AtomicLong counter = localCounters.computeIfAbsent(key, k -> new AtomicLong(0));
        long current = counter.incrementAndGet();
        if (current > config.limit) {
            log.warn("触发本地限流 [{}]: key={}, count={}/{}", config.name, key, current, config.limit);
            return rateLimitResponse(exchange.getResponse(), config);
        }
        return chain.filter(exchange);
    }

    private Mono<Void> rateLimitResponse(ServerHttpResponse response, RateLimitConfig config) {
        response.setStatusCode(HttpStatus.TOO_MANY_REQUESTS);
        response.getHeaders().setContentType(MediaType.APPLICATION_JSON);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("code", 429);
        result.put("message", "请求过于频繁，请稍后再试");
        result.put("data", null);
        result.put("timestamp", System.currentTimeMillis());

        try {
            byte[] bytes = objectMapper.writeValueAsBytes(result);
            DataBuffer buffer = response.bufferFactory().wrap(bytes);
            return response.writeWith(Mono.just(buffer));
        } catch (JsonProcessingException e) {
            log.error("Failed to write rate limit response", e);
            return response.setComplete();
        }
    }

    private String getClientIp(ServerHttpRequest request) {
        String ip = request.getHeaders().getFirst("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeaders().getFirst("X-Real-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            var remote = request.getRemoteAddress();
            ip = remote == null ? "unknown" : remote.getAddress().getHostAddress();
        }
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        return ip == null ? "unknown" : ip;
    }

    @Override
    public int getOrder() {
        return -50;  // 在 AuthFilter(-100) 之后执行
    }

    /** 限流配置项 */
    private record RateLimitConfig(String name, int limit, long windowSeconds) {}
}
