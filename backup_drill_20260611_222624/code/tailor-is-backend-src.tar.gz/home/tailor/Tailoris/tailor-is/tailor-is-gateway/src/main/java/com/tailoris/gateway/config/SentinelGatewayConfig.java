package com.tailoris.gateway.config;

import com.alibaba.csp.sentinel.adapter.gateway.common.rule.GatewayFlowRule;
import com.alibaba.csp.sentinel.adapter.gateway.common.rule.GatewayRuleManager;
import com.alibaba.csp.sentinel.adapter.gateway.sc.SentinelGatewayFilter;
import com.alibaba.csp.sentinel.adapter.gateway.sc.callback.BlockRequestHandler;
import com.alibaba.csp.sentinel.adapter.gateway.sc.callback.GatewayCallbackManager;
import com.alibaba.csp.sentinel.adapter.gateway.sc.exception.SentinelGatewayBlockExceptionHandler;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerResponse;
import org.springframework.web.reactive.result.view.ViewResolver;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import jakarta.annotation.PostConstruct;
import java.util.*;

/**
 * Sentinel Gateway 配置
 * 替代原 Resilience4j 的限流熔断功能
 * 提供 Gateway 级别的流控规则和自定义被限流响应
 */
@Configuration
public class SentinelGatewayConfig {

    private final List<ViewResolver> viewResolvers;
    private final ServerCodecConfigurer serverCodecConfigurer;

    public SentinelGatewayConfig(
            ObjectProvider<List<ViewResolver>> viewResolversProvider,
            ServerCodecConfigurer serverCodecConfigurer) {
        this.viewResolvers = viewResolversProvider.getIfAvailable(Collections::emptyList);
        this.serverCodecConfigurer = serverCodecConfigurer;
    }

    /**
     * 自定义被限流/熔断时的异常处理器
     * 返回 JSON 格式的错误响应
     */
    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE)
    public SentinelGatewayBlockExceptionHandler sentinelGatewayBlockExceptionHandler() {
        return new SentinelGatewayBlockExceptionHandler(viewResolvers, serverCodecConfigurer);
    }

    /**
     * 自定义 Block 请求处理器
     */
    @PostConstruct
    public void initBlockHandler() {
        BlockRequestHandler blockHandler = (ServerWebExchange exchange, Throwable ex) -> {
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("code", HttpStatus.TOO_MANY_REQUESTS.value());
            result.put("message", "请求过于频繁,请稍后再试");
            result.put("data", null);
            return ServerResponse
                    .status(HttpStatus.TOO_MANY_REQUESTS)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(result));
        };
        GatewayCallbackManager.setBlockHandler(blockHandler);
    }

    /**
     * Sentinel Gateway Filter
     * 必须在 Gateway 路由处理之前执行
     */
    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE)
    public GlobalFilter sentinelGatewayFilter() {
        return new SentinelGatewayFilter();
    }

    /**
     * 初始化 Gateway 流控规则
     * 生产环境中建议通过 Nacos/Sentinel Dashboard 动态配置
     */
    @PostConstruct
    public void initGatewayRules() {
        Set<GatewayFlowRule> rules = new HashSet<>();

        // 登录接口: 严格限流 10 QPS (对应原 Resilience4j loginLimiter strict 模式)
        rules.add(new GatewayFlowRule("tailor-is-user")
                .setResourceMode(GatewayRuleManager.RESOURCE_MODE_ROUTE_ID)
                .setCount(10)
                .setIntervalSec(1)
                .setControlBehavior(GatewayRuleManager.CONTROL_BEHAVIOR_RATE_LIMITER)
                .setMaxQueueingTimeoutMs(0));

        // 支付接口: 限流 50 QPS
        rules.add(new GatewayFlowRule("tailor-is-payment")
                .setResourceMode(GatewayRuleManager.RESOURCE_MODE_ROUTE_ID)
                .setCount(50)
                .setIntervalSec(1));

        // AI 接口: 限流 20 QPS (AI 推理通常资源消耗较大)
        rules.add(new GatewayFlowRule("tailor-is-ai")
                .setResourceMode(GatewayRuleManager.RESOURCE_MODE_ROUTE_ID)
                .setCount(20)
                .setIntervalSec(1));

        // 订单接口: 限流 100 QPS (对应原 Resilience4j apiLimiter default 模式)
        rules.add(new GatewayFlowRule("tailor-is-order")
                .setResourceMode(GatewayRuleManager.RESOURCE_MODE_ROUTE_ID)
                .setCount(100)
                .setIntervalSec(1));

        // 商品接口: 限流 200 QPS (读取为主, 可适当放宽)
        rules.add(new GatewayFlowRule("tailor-is-product")
                .setResourceMode(GatewayRuleManager.RESOURCE_MODE_ROUTE_ID)
                .setCount(200)
                .setIntervalSec(1));

        GatewayRuleManager.loadRules(rules);
    }
}
