package com.tailoris.payment.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tailoris.payment.entity.ReconciliationRecord;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ReconciliationRecordMapper extends BaseMapper<ReconciliationRecord> {
}